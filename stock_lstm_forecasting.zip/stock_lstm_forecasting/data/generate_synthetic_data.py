"""
generate_synthetic_data.py
---------------------------
Generates a synthetic, but realistic, daily stock price series and saves it
as `data/sample_stock_data.csv`. This dataset ships with the project so
that the whole pipeline (preprocessing -> training -> evaluation) can be
run immediately, with no internet connection or API key required.

The series is built from:
  - A geometric Brownian motion component (random walk with drift) to
    mimic real stock price behaviour.
  - A slow-moving sinusoidal trend to emulate multi-month market cycles.
  - Volume data correlated with absolute daily price change (higher volume
    on bigger moves, as is typically observed in real markets).
  - A handful of randomly injected missing values (NaNs), so the
    preprocessing step has real missing-value handling to perform.

To use REAL market data instead, run `data/download_data.py` (requires
internet + yfinance) and point `main.py` at the resulting CSV.

Author: Tharun Velan Charan
"""

import os

import numpy as np
import pandas as pd


def generate_synthetic_stock_data(
    n_days: int = 1500,
    start_price: float = 150.0,
    mu: float = 0.0004,
    sigma: float = 0.018,
    seed: int = 42,
    out_path: str = None,
) -> pd.DataFrame:
    """Generate a synthetic OHLCV stock dataset.

    Args:
        n_days: Number of trading days to simulate.
        start_price: Starting closing price.
        mu: Daily drift (expected return) of the random walk.
        sigma: Daily volatility of the random walk.
        seed: Random seed for reproducibility.
        out_path: If provided, saves the DataFrame to this CSV path.

    Returns:
        A DataFrame with columns: Date, Open, High, Low, Close, Volume.
    """
    rng = np.random.default_rng(seed)

    dates = pd.bdate_range(start="2018-01-01", periods=n_days)  # business days only

    # Geometric Brownian motion (log-returns) component
    daily_returns = rng.normal(loc=mu, scale=sigma, size=n_days)

    # Slow sinusoidal macro trend (≈ 1 cycle per 250 trading days ≈ 1 year)
    macro_cycle = 0.0006 * np.sin(np.linspace(0, 6 * np.pi, n_days))

    log_returns = daily_returns + macro_cycle
    close = start_price * np.exp(np.cumsum(log_returns))

    # Derive Open/High/Low from Close with small random intraday noise
    intraday_noise = rng.normal(0, sigma / 4, size=n_days)
    open_price = close * (1 + intraday_noise)
    high = np.maximum(open_price, close) * (1 + np.abs(rng.normal(0, sigma / 3, size=n_days)))
    low = np.minimum(open_price, close) * (1 - np.abs(rng.normal(0, sigma / 3, size=n_days)))

    # Volume: baseline + scaled by magnitude of price move (mimics real markets)
    price_change_pct = np.abs(np.diff(close, prepend=close[0])) / close
    volume = (5_000_000 + 8_000_000 * (price_change_pct / price_change_pct.max())).astype(int)
    volume += rng.integers(-200_000, 200_000, size=n_days)
    volume = np.clip(volume, 1_000_000, None)

    df = pd.DataFrame(
        {
            "Date": dates,
            "Open": open_price.round(2),
            "High": high.round(2),
            "Low": low.round(2),
            "Close": close.round(2),
            "Volume": volume,
        }
    )

    # Inject a handful of missing values to exercise the cleaning step
    missing_idx = rng.choice(df.index[5:], size=max(5, n_days // 150), replace=False)
    df.loc[missing_idx, "Close"] = np.nan

    if out_path:
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        df.to_csv(out_path, index=False)
        print(f"Synthetic dataset with {len(df)} rows saved to {out_path}")

    return df


if __name__ == "__main__":
    out_csv = os.path.join(os.path.dirname(__file__), "sample_stock_data.csv")
    generate_synthetic_stock_data(out_path=out_csv)
