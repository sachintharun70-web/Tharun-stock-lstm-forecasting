"""
download_data.py
-----------------
Downloads real historical stock price data from Yahoo Finance using the
`yfinance` package and saves it as a CSV file in the `data/` folder.

This script requires an internet connection. Run it once before running
`main.py` if you want to train on real market data instead of the bundled
synthetic sample dataset (`sample_stock_data.csv`).

Usage:
    python data/download_data.py --ticker AAPL --start 2015-01-01 --end 2025-01-01

Author: Tharun Velan Charan
"""

import argparse
import os

import pandas as pd


def download_stock_data(ticker: str, start: str, end: str, out_path: str) -> pd.DataFrame:
    """Download OHLCV data for a given ticker and save it as a CSV.

    Args:
        ticker: Stock ticker symbol, e.g. "AAPL".
        start: Start date in YYYY-MM-DD format.
        end: End date in YYYY-MM-DD format.
        out_path: File path to save the resulting CSV.

    Returns:
        The downloaded DataFrame.
    """
    try:
        import yfinance as yf
    except ImportError as exc:
        raise ImportError(
            "yfinance is required for this script. Install it with "
            "'pip install yfinance'."
        ) from exc

    print(f"Downloading {ticker} data from {start} to {end} ...")
    df = yf.download(ticker, start=start, end=end)

    if df.empty:
        raise ValueError(
            f"No data returned for ticker '{ticker}'. Check the symbol and date range."
        )

    df.reset_index(inplace=True)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    df.to_csv(out_path, index=False)
    print(f"Saved {len(df)} rows to {out_path}")
    return df


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Download stock data from Yahoo Finance.")
    parser.add_argument("--ticker", type=str, default="AAPL", help="Stock ticker symbol.")
    parser.add_argument("--start", type=str, default="2015-01-01", help="Start date (YYYY-MM-DD).")
    parser.add_argument("--end", type=str, default="2025-01-01", help="End date (YYYY-MM-DD).")
    parser.add_argument(
        "--out",
        type=str,
        default=os.path.join(os.path.dirname(__file__), "stock_data.csv"),
        help="Output CSV path.",
    )
    args = parser.parse_args()

    download_stock_data(args.ticker, args.start, args.end, args.out)
