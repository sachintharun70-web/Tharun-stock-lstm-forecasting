"""
lstm_model.py
--------------
A Long Short-Term Memory (LSTM) network implemented from scratch using
only NumPy. This avoids any dependency on TensorFlow/PyTorch, so the
project runs in any plain Python + NumPy environment with no GPU and no
extra installs.

Architecture
------------
Input sequence (window_size timesteps x n_features)
        |
        v
  LSTM layer (hidden_size units)
   - forget gate  f_t = sigmoid(Wf . [h_{t-1}, x_t] + bf)
   - input  gate  i_t = sigmoid(Wi . [h_{t-1}, x_t] + bi)
   - candidate    g_t = tanh   (Wc . [h_{t-1}, x_t] + bc)
   - output gate  o_t = sigmoid(Wo . [h_{t-1}, x_t] + bo)
   - cell state   c_t = f_t * c_{t-1} + i_t * g_t
   - hidden state h_t = o_t * tanh(c_t)
        |  (only the FINAL hidden state h_T is used — "many-to-one")
        v
  Dense output layer: y_hat = Wy . h_T + by   (linear activation, regression)

Training: Backpropagation Through Time (BPTT), mini-batch gradient
descent, optimized with Adam. Loss: Mean Squared Error.

Author: Tharun Velan Charan
"""

from dataclasses import dataclass
from typing import List

import numpy as np


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -500, 500)))


def dsigmoid(y: np.ndarray) -> np.ndarray:
    """Derivative of sigmoid, given y = sigmoid(x)."""
    return y * (1 - y)


def dtanh(y: np.ndarray) -> np.ndarray:
    """Derivative of tanh, given y = tanh(x)."""
    return 1 - y ** 2


@dataclass
class LSTMConfig:
    input_size: int
    hidden_size: int = 32
    learning_rate: float = 0.005
    epochs: int = 60
    batch_size: int = 32
    clip_value: float = 5.0
    seed: int = 7


class LSTMNumpy:
    """Single-layer LSTM + linear output head, implemented with raw NumPy."""

    def __init__(self, config: LSTMConfig):
        self.cfg = config
        rng = np.random.default_rng(config.seed)
        H, D = config.hidden_size, config.input_size
        concat_size = H + D

        # Xavier-style initialization keeps gate pre-activations well-scaled.
        def init_weight(rows, cols):
            limit = np.sqrt(6.0 / (rows + cols))
            return rng.uniform(-limit, limit, size=(rows, cols))

        self.params = {
            "Wf": init_weight(H, concat_size), "bf": np.zeros((H, 1)),
            "Wi": init_weight(H, concat_size), "bi": np.zeros((H, 1)),
            "Wc": init_weight(H, concat_size), "bc": np.zeros((H, 1)),
            "Wo": init_weight(H, concat_size), "bo": np.zeros((H, 1)),
            "Wy": init_weight(1, H),           "by": np.zeros((1, 1)),
        }

        # Adam optimizer state (1st and 2nd moment estimates per parameter)
        self.m = {k: np.zeros_like(v) for k, v in self.params.items()}
        self.v = {k: np.zeros_like(v) for k, v in self.params.items()}
        self.t = 0  # Adam timestep

        self.train_loss_history: List[float] = []

    # ------------------------------------------------------------------ #
    # Forward pass
    # ------------------------------------------------------------------ #
    def forward(self, X_batch: np.ndarray):
        """Run the LSTM forward over a batch of sequences.

        Args:
            X_batch: shape (batch, T, input_size)

        Returns:
            y_hat: shape (batch, 1) — predicted next value
            cache: dict of per-timestep activations needed for backprop
        """
        B, T, D = X_batch.shape
        H = self.cfg.hidden_size
        p = self.params

        h = np.zeros((B, H))
        c = np.zeros((B, H))

        cache = {
            "x": [], "h": [h.copy()], "c": [c.copy()],
            "f": [], "i": [], "o": [], "g": [], "concat": [],
        }

        for t in range(T):
            x_t = X_batch[:, t, :]               # (B, D)
            concat = np.concatenate([h, x_t], axis=1)  # (B, H+D)

            f_t = sigmoid(concat @ p["Wf"].T + p["bf"].T)
            i_t = sigmoid(concat @ p["Wi"].T + p["bi"].T)
            g_t = np.tanh(concat @ p["Wc"].T + p["bc"].T)
            o_t = sigmoid(concat @ p["Wo"].T + p["bo"].T)

            c = f_t * c + i_t * g_t
            h = o_t * np.tanh(c)

            cache["x"].append(x_t)
            cache["concat"].append(concat)
            cache["f"].append(f_t)
            cache["i"].append(i_t)
            cache["g"].append(g_t)
            cache["o"].append(o_t)
            cache["h"].append(h.copy())
            cache["c"].append(c.copy())

        y_hat = h @ p["Wy"].T + p["by"].T  # (B, 1) — linear regression head on final hidden state
        cache["h_final"] = h
        return y_hat, cache

    # ------------------------------------------------------------------ #
    # Backward pass (BPTT)
    # ------------------------------------------------------------------ #
    def backward(self, X_batch: np.ndarray, y_true: np.ndarray, y_hat: np.ndarray, cache: dict):
        B, T, D = X_batch.shape
        H = self.cfg.hidden_size
        p = self.params

        grads = {k: np.zeros_like(v) for k, v in p.items()}

        # dL/dy_hat for MSE loss: 2*(y_hat - y_true)/B  (mean over batch)
        dy = (2.0 / B) * (y_hat - y_true)          # (B, 1)
        grads["Wy"] = dy.T @ cache["h_final"]      # (1, H)
        grads["by"] = dy.sum(axis=0, keepdims=True).T

        dh_next = dy @ p["Wy"]                     # (B, H) grad flowing into final hidden state
        dc_next = np.zeros((B, H))

        for t in reversed(range(T)):
            h_prev, c_prev = cache["h"][t], cache["c"][t]
            c_t = cache["c"][t + 1]
            f_t, i_t, g_t, o_t = cache["f"][t], cache["i"][t], cache["g"][t], cache["o"][t]
            concat = cache["concat"][t]

            tanh_c = np.tanh(c_t)
            do = dh_next * tanh_c
            dc = dh_next * o_t * dtanh(tanh_c) + dc_next

            df = dc * c_prev
            di = dc * g_t
            dg = dc * i_t
            dc_prev = dc * f_t

            # Raw pre-activation gradients
            df_raw = df * dsigmoid(f_t)
            di_raw = di * dsigmoid(i_t)
            do_raw = do * dsigmoid(o_t)
            dg_raw = dg * dtanh(g_t)

            grads["Wf"] += df_raw.T @ concat
            grads["bf"] += df_raw.sum(axis=0, keepdims=True).T
            grads["Wi"] += di_raw.T @ concat
            grads["bi"] += di_raw.sum(axis=0, keepdims=True).T
            grads["Wc"] += dg_raw.T @ concat
            grads["bc"] += dg_raw.sum(axis=0, keepdims=True).T
            grads["Wo"] += do_raw.T @ concat
            grads["bo"] += do_raw.sum(axis=0, keepdims=True).T

            d_concat = (
                df_raw @ p["Wf"] + di_raw @ p["Wi"] + dg_raw @ p["Wc"] + do_raw @ p["Wo"]
            )
            dh_prev = d_concat[:, :H]

            dh_next = dh_prev
            dc_next = dc_prev

        # Gradient clipping to prevent exploding gradients over long sequences
        for k in grads:
            np.clip(grads[k], -self.cfg.clip_value, self.cfg.clip_value, out=grads[k])

        return grads

    # ------------------------------------------------------------------ #
    # Adam optimizer step
    # ------------------------------------------------------------------ #
    def adam_step(self, grads: dict, beta1=0.9, beta2=0.999, eps=1e-8):
        self.t += 1
        lr = self.cfg.learning_rate
        for k in self.params:
            self.m[k] = beta1 * self.m[k] + (1 - beta1) * grads[k]
            self.v[k] = beta2 * self.v[k] + (1 - beta2) * (grads[k] ** 2)
            m_hat = self.m[k] / (1 - beta1 ** self.t)
            v_hat = self.v[k] / (1 - beta2 ** self.t)
            self.params[k] -= lr * m_hat / (np.sqrt(v_hat) + eps)

    # ------------------------------------------------------------------ #
    # Training loop
    # ------------------------------------------------------------------ #
    def fit(self, X_train: np.ndarray, y_train: np.ndarray, verbose: bool = True):
        n_samples = X_train.shape[0]
        rng = np.random.default_rng(self.cfg.seed)

        for epoch in range(1, self.cfg.epochs + 1):
            perm = rng.permutation(n_samples)
            X_shuf, y_shuf = X_train[perm], y_train[perm]

            epoch_losses = []
            for start in range(0, n_samples, self.cfg.batch_size):
                end = start + self.cfg.batch_size
                X_batch, y_batch = X_shuf[start:end], y_shuf[start:end]

                y_hat, cache = self.forward(X_batch)
                loss = np.mean((y_hat - y_batch) ** 2)
                grads = self.backward(X_batch, y_batch, y_hat, cache)
                self.adam_step(grads)

                epoch_losses.append(loss)

            mean_loss = float(np.mean(epoch_losses))
            self.train_loss_history.append(mean_loss)

            if verbose and (epoch == 1 or epoch % 5 == 0 or epoch == self.cfg.epochs):
                print(f"Epoch {epoch:3d}/{self.cfg.epochs} | Train MSE (scaled): {mean_loss:.6f}")

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Run inference in batches (avoids huge memory use on big test sets)."""
        preds = []
        bs = self.cfg.batch_size
        for start in range(0, len(X), bs):
            y_hat, _ = self.forward(X[start : start + bs])
            preds.append(y_hat)
        return np.concatenate(preds, axis=0)

    def save(self, path: str):
        np.savez(path, **self.params)

    def load(self, path: str):
        loaded = np.load(path)
        for k in self.params:
            self.params[k] = loaded[k]
