"""
data_preprocessing.py
----------------------
Handles all data preparation for the LSTM stock forecasting model:

  1. Loading the raw CSV.
  2. Cleaning missing values.
  3. Feature engineering (returns, moving averages, volatility).
  4. Feature selection (choosing which engineered columns feed the model).
  5. Scaling features with MinMaxScaler (fit on train data only, to avoid
     data leakage from the test set).
  6. Building sliding-window sequences (X = past `window_size` days of
     features, y = next day's closing price) for supervised learning.
  7. Chronological train/test split (time series data must NOT be
     shuffled before splitting).

Author: Tharun Velan Charan
"""

from dataclasses import dataclass
from typing import Tuple

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler


# Columns used as model inputs. "Close" is also the prediction target.
FEATURE_COLUMNS = ["Close", "MA_7", "Daily_Return", "Volatility_7"]
TARGET_COLUMN = "Close"


@dataclass
class PreparedData:
    """Container holding everything downstream code needs."""

    X_train: np.ndarray
    y_train: np.ndarray
    X_test: np.ndarray
    y_test: np.ndarray
    feature_scaler: MinMaxScaler
    target_scaler: MinMaxScaler
    train_dates: pd.Series
    test_dates: pd.Series
    raw_df: pd.DataFrame


def load_data(csv_path: str) -> pd.DataFrame:
    """Load raw OHLCV data from CSV and parse dates."""
    df = pd.read_csv(csv_path, parse_dates=["Date"])
    df.sort_values("Date", inplace=True)
    df.reset_index(drop=True, inplace=True)
    return df


def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """Clean missing values in the price columns.

    Strategy:
      - Forward-fill first (a missing close price is reasonably assumed to
        be close to the previous trading day's value).
      - Back-fill any remaining NaNs at the very start of the series.
      - Drop any rows that are still incomplete (defensive fallback).
    """
    df = df.copy()
    price_cols = [c for c in ["Open", "High", "Low", "Close", "Volume"] if c in df.columns]
    n_missing_before = df[price_cols].isna().sum().sum()

    df[price_cols] = df[price_cols].ffill().bfill()
    df.dropna(subset=price_cols, inplace=True)
    df.reset_index(drop=True, inplace=True)

    n_missing_after = df[price_cols].isna().sum().sum()
    print(
        f"[Preprocessing] Missing values handled: {n_missing_before} -> {n_missing_after} "
        f"(forward-fill + back-fill)."
    )
    return df


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """Create additional predictive features from the raw OHLCV data.

    Features added:
      - Daily_Return: percentage change in closing price.
      - MA_7 / MA_21: 7-day and 21-day simple moving averages (trend).
      - Volatility_7: rolling 7-day standard deviation of returns (risk).
    """
    df = df.copy()
    df["Daily_Return"] = df["Close"].pct_change()
    df["MA_7"] = df["Close"].rolling(window=7).mean()
    df["MA_21"] = df["Close"].rolling(window=21).mean()
    df["Volatility_7"] = df["Daily_Return"].rolling(window=7).std()

    # Rolling windows introduce NaNs at the start of the series; drop those rows.
    df.dropna(inplace=True)
    df.reset_index(drop=True, inplace=True)
    return df


def scale_features(
    df: pd.DataFrame, train_size: int
) -> Tuple[np.ndarray, np.ndarray, MinMaxScaler, MinMaxScaler]:
    """Scale selected features and the target to the [0, 1] range.

    Scalers are fit ONLY on the training portion of the data to prevent
    information from the test set leaking into the training process.
    """
    feature_scaler = MinMaxScaler(feature_range=(0, 1))
    target_scaler = MinMaxScaler(feature_range=(0, 1))

    features = df[FEATURE_COLUMNS].values
    target = df[[TARGET_COLUMN]].values

    feature_scaler.fit(features[:train_size])
    target_scaler.fit(target[:train_size])

    scaled_features = feature_scaler.transform(features)
    scaled_target = target_scaler.transform(target)

    return scaled_features, scaled_target, feature_scaler, target_scaler


def create_sequences(
    features: np.ndarray, target: np.ndarray, window_size: int
) -> Tuple[np.ndarray, np.ndarray]:
    """Build sliding-window sequences for supervised time-series learning.

    For each index i, X[i] = features[i : i+window_size]  (shape: window_size x n_features)
                       y[i] = target[i+window_size]        (the next day's scaled close price)
    """
    X, y = [], []
    for i in range(len(features) - window_size):
        X.append(features[i : i + window_size])
        y.append(target[i + window_size])
    return np.array(X), np.array(y)


def prepare_data(
    csv_path: str,
    window_size: int = 60,
    test_ratio: float = 0.2,
) -> PreparedData:
    """End-to-end preprocessing pipeline: load -> clean -> engineer -> scale -> window -> split.

    Args:
        csv_path: Path to raw stock CSV (must contain at least Date, Close).
        window_size: Number of past days used to predict the next day.
        test_ratio: Fraction of the (chronologically ordered) data held out for testing.

    Returns:
        A PreparedData object containing train/test arrays and fitted scalers.
    """
    df = load_data(csv_path)
    df = handle_missing_values(df)
    df = engineer_features(df)

    # Chronological split point — NEVER shuffle time series data before splitting.
    n_total = len(df)
    n_train = int(n_total * (1 - test_ratio))

    scaled_features, scaled_target, feature_scaler, target_scaler = scale_features(df, n_train)
    X, y = create_sequences(scaled_features, scaled_target, window_size)

    # Sequence i uses features[i:i+window_size] and predicts target[i+window_size].
    # So sequence index n_train - window_size is the last sequence fully inside the
    # training period; everything after that is test data.
    split_idx = n_train - window_size

    X_train, y_train = X[:split_idx], y[:split_idx]
    X_test, y_test = X[split_idx:], y[split_idx:]

    dates = df["Date"].reset_index(drop=True)
    train_dates = dates[window_size : window_size + len(X_train)].reset_index(drop=True)
    test_dates = dates[window_size + len(X_train) : window_size + len(X_train) + len(X_test)].reset_index(
        drop=True
    )

    print(
        f"[Preprocessing] Total samples: {n_total} | Window size: {window_size} | "
        f"Train sequences: {len(X_train)} | Test sequences: {len(X_test)}"
    )
    print(f"[Preprocessing] Features used: {FEATURE_COLUMNS}")

    return PreparedData(
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        feature_scaler=feature_scaler,
        target_scaler=target_scaler,
        train_dates=train_dates,
        test_dates=test_dates,
        raw_df=df,
    )


if __name__ == "__main__":
    # Quick smoke test
    data = prepare_data("data/sample_stock_data.csv")
    print("X_train shape:", data.X_train.shape)
    print("y_train shape:", data.y_train.shape)
    print("X_test shape:", data.X_test.shape)
    print("y_test shape:", data.y_test.shape)
