"""
evaluate.py
------------
Evaluation utilities for the LSTM stock forecasting model:

  - Computes MAE, RMSE, and MSE in REAL price units (after inverse-scaling
    predictions back from the [0,1] range), since scaled-space errors are
    not interpretable to a human reader.
  - Produces two plots: the training loss curve, and predicted vs. actual
    closing prices on the held-out test set.

Author: Tharun Velan Charan
"""

import json
import os

import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import MinMaxScaler


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """Compute MAE, MSE, RMSE between true and predicted values (same units)."""
    y_true = y_true.flatten()
    y_pred = y_pred.flatten()

    mae = float(np.mean(np.abs(y_true - y_pred)))
    mse = float(np.mean((y_true - y_pred) ** 2))
    rmse = float(np.sqrt(mse))

    # Mean Absolute Percentage Error, useful for relative interpretation
    mape = float(np.mean(np.abs((y_true - y_pred) / y_true)) * 100)

    return {"MAE": mae, "MSE": mse, "RMSE": rmse, "MAPE_%": mape}


def inverse_scale(scaled_values: np.ndarray, scaler: MinMaxScaler) -> np.ndarray:
    """Convert scaled [0,1] predictions/targets back to real price units."""
    return scaler.inverse_transform(scaled_values.reshape(-1, 1)).flatten()


def plot_loss_curve(loss_history: list, save_path: str):
    plt.figure(figsize=(9, 5))
    plt.plot(loss_history, color="#1f77b4", linewidth=2)
    plt.title("Training Loss (MSE, scaled space) over Epochs")
    plt.xlabel("Epoch")
    plt.ylabel("Mean Squared Error")
    plt.grid(alpha=0.3)
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f"[Evaluate] Saved loss curve to {save_path}")


def plot_predictions_vs_actual(
    dates, y_true_real: np.ndarray, y_pred_real: np.ndarray, save_path: str, title: str
):
    plt.figure(figsize=(12, 6))
    plt.plot(dates, y_true_real, label="Actual Close Price", color="#2ca02c", linewidth=1.8)
    plt.plot(dates, y_pred_real, label="Predicted Close Price", color="#d62728", linewidth=1.8, linestyle="--")
    plt.title(title)
    plt.xlabel("Date")
    plt.ylabel("Price ($)")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.xticks(rotation=30)
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f"[Evaluate] Saved predictions-vs-actual plot to {save_path}")


def plot_raw_price_history(df, date_col: str, price_col: str, save_path: str):
    plt.figure(figsize=(12, 5))
    plt.plot(df[date_col], df[price_col], color="#1f77b4", linewidth=1.2)
    plt.title("Historical Closing Price")
    plt.xlabel("Date")
    plt.ylabel("Price ($)")
    plt.grid(alpha=0.3)
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f"[Evaluate] Saved raw price history plot to {save_path}")


def save_metrics_json(metrics: dict, save_path: str):
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, "w") as f:
        json.dump(metrics, f, indent=2)
    print(f"[Evaluate] Saved metrics to {save_path}")
