"""
main.py
--------
End-to-end pipeline for LSTM-based stock price forecasting:

    1. Load + preprocess data (data/sample_stock_data.csv by default).
    2. Train a from-scratch NumPy LSTM model.
    3. Evaluate on the held-out test set (MAE / MSE / RMSE / MAPE).
    4. Save plots (loss curve, predictions vs. actual) and metrics to outputs/.

Run from the project root:
    python main.py
    python main.py --csv data/stock_data.csv --window 60 --epochs 60 --hidden 32

Author: Tharun Velan Charan
"""

import argparse
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from data_preprocessing import prepare_data  # noqa: E402
from lstm_model import LSTMNumpy, LSTMConfig  # noqa: E402
from evaluate import (  # noqa: E402
    compute_metrics,
    inverse_scale,
    plot_loss_curve,
    plot_predictions_vs_actual,
    plot_raw_price_history,
    save_metrics_json,
)


def main():
    parser = argparse.ArgumentParser(description="LSTM Stock Price Forecasting")
    parser.add_argument("--csv", type=str, default="data/sample_stock_data.csv", help="Path to input CSV.")
    parser.add_argument("--window", type=int, default=60, help="Sliding window size (days of history per sample).")
    parser.add_argument("--hidden", type=int, default=32, help="LSTM hidden layer size.")
    parser.add_argument("--epochs", type=int, default=60, help="Training epochs.")
    parser.add_argument("--batch_size", type=int, default=32, help="Mini-batch size.")
    parser.add_argument("--lr", type=float, default=0.005, help="Learning rate.")
    parser.add_argument("--test_ratio", type=float, default=0.2, help="Fraction of data reserved for testing.")
    parser.add_argument("--outdir", type=str, default="outputs", help="Directory to save outputs.")
    args = parser.parse_args()

    print("=" * 70)
    print("LSTM STOCK PRICE FORECASTING — TRAINING PIPELINE")
    print("=" * 70)

    # ------------------------------------------------------------------ #
    # 1. Data preprocessing
    # ------------------------------------------------------------------ #
    data = prepare_data(args.csv, window_size=args.window, test_ratio=args.test_ratio)

    plot_raw_price_history(
        data.raw_df, "Date", "Close", os.path.join(args.outdir, "plots", "price_history.png")
    )

    n_features = data.X_train.shape[2]

    # ------------------------------------------------------------------ #
    # 2. Build + train the LSTM
    # ------------------------------------------------------------------ #
    config = LSTMConfig(
        input_size=n_features,
        hidden_size=args.hidden,
        learning_rate=args.lr,
        epochs=args.epochs,
        batch_size=args.batch_size,
    )
    model = LSTMNumpy(config)

    print("\n[Train] Starting training...")
    start = time.time()
    model.fit(data.X_train, data.y_train, verbose=True)
    print(f"[Train] Completed in {time.time() - start:.1f} seconds.\n")

    plot_loss_curve(model.train_loss_history, os.path.join(args.outdir, "plots", "loss_curve.png"))

    # ------------------------------------------------------------------ #
    # 3. Evaluate on train + test sets
    # ------------------------------------------------------------------ #
    y_train_pred_scaled = model.predict(data.X_train)
    y_test_pred_scaled = model.predict(data.X_test)

    y_train_true_real = inverse_scale(data.y_train, data.target_scaler)
    y_train_pred_real = inverse_scale(y_train_pred_scaled, data.target_scaler)
    y_test_true_real = inverse_scale(data.y_test, data.target_scaler)
    y_test_pred_real = inverse_scale(y_test_pred_scaled, data.target_scaler)

    train_metrics = compute_metrics(y_train_true_real, y_train_pred_real)
    test_metrics = compute_metrics(y_test_true_real, y_test_pred_real)

    print("[Evaluate] TRAIN metrics (real price units):")
    for k, v in train_metrics.items():
        print(f"    {k}: {v:.4f}")

    print("[Evaluate] TEST metrics (real price units):")
    for k, v in test_metrics.items():
        print(f"    {k}: {v:.4f}")

    save_metrics_json(
        {"train": train_metrics, "test": test_metrics, "config": vars(config)},
        os.path.join(args.outdir, "metrics", "metrics.json"),
    )

    # ------------------------------------------------------------------ #
    # 4. Visualizations
    # ------------------------------------------------------------------ #
    plot_predictions_vs_actual(
        data.test_dates,
        y_test_true_real,
        y_test_pred_real,
        os.path.join(args.outdir, "plots", "predictions_vs_actual_test.png"),
        title="LSTM Forecast vs. Actual Closing Price (Test Set)",
    )

    plot_predictions_vs_actual(
        data.train_dates,
        y_train_true_real,
        y_train_pred_real,
        os.path.join(args.outdir, "plots", "predictions_vs_actual_train.png"),
        title="LSTM Forecast vs. Actual Closing Price (Train Set)",
    )

    model.save(os.path.join(args.outdir, "lstm_weights.npz"))
    print(f"\n[Done] Model weights saved to {os.path.join(args.outdir, 'lstm_weights.npz')}")
    print("[Done] All plots and metrics saved under:", args.outdir)


if __name__ == "__main__":
    main()
